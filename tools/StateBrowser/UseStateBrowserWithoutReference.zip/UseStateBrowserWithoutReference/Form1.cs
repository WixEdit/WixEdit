using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;

namespace UseStateBrowserWithoutReference
{
	public class Form1 : System.Windows.Forms.Form
	{
		private void button1_Click(object sender, System.EventArgs e)
		{
			// Load assembly from GAC
			Assembly stateBrowserAssm = Assembly.Load("sliver.windows.forms.statebrowser, Version=1.5.0.0, Culture=neutral, PublicKeyToken=34afe62596d00324, Custom=null");
			
			// Get form type
			Type stateBrowserFormType = stateBrowserAssm.GetType("sliver.Windows.Forms.StateBrowserForm");

			// Get ObjectToBrowse property
			PropertyInfo objectToBrowseProp = stateBrowserFormType.GetProperty("ObjectToBrowse");
	
			// Get the Show method
			MethodInfo showMethod = stateBrowserFormType.GetMethod("Show");

			// Create instance of form
			object stateBrowserForm  = Activator.CreateInstance(stateBrowserFormType);

			// Set ObjectToBrowse property to this form
			objectToBrowseProp.SetValue(stateBrowserForm, this, new object[0]);

			// Show the form
			showMethod.Invoke(stateBrowserForm, null);
		}

		#region DesignerStuff

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(188, 44);
			this.label1.TabIndex = 0;
			this.label1.Text = "Note that the sliver.Windows.Forms.StateBrowser assembly must be in the GAC.";
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(84, 64);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(112, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Show This Form";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(204, 98);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		#endregion
	}
}
